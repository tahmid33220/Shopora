# Reseller Store - Free Starter Website

## 1. Change brand name
Open `index.html` and find:
`name: "YOUR BRAND"`
Replace YOUR BRAND with your shop name.

## 2. Change WhatsApp
Find:
`phone: "8801XXXXXXXXX"`
Use your WhatsApp number with country code, without + or spaces.
Example: 8801712345678

## 3. Add/change products
Inside `const products = [...]`, copy a product object and change:
- name
- cat
- price
- old
- img

Categories currently supported:
Clothing, Electronics, Shoes, Men, Women.

## 4. Free hosting
You can upload `index.html` to GitHub Pages or another static free host.

Important:
The product demo images use external image URLs. For a real store, replace them with your own product images.

## 5. Orders
The Buy Now button opens WhatsApp with the customer's order details.
Make sure the WhatsApp number in STORE.phone is correct.
